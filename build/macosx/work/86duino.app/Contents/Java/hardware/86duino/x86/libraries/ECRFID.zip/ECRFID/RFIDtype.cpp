#include "RFIDtype.h"
#include <stdlib.h>

void makeSendCommand(CARDCOMMAND command, char* data, char** ret, int* size) {
    char* c;
    int _size;
    
    if (command == SCAN_CARD) {
        _size = 3;
        c = (char*)malloc(_size);
        c[0] = (char)SCAN_CARD;
        c[1] = data[0]; // Timeout LowByte
        c[2] = data[1]; // Timeout HighByte
        *size = _size;
    } else if (command == SELECT_CARD) {
        _size = 9;
        c = (char*)malloc(_size);
        c[0] = (char)SELECT_CARD;
        c[1] = data[0]; // UID size
        for (int i=0; i<(_size-2); i++) c[2+i] = data[1+i]; // UID data
        *size = _size;
    } else if (command == READ_CARD) {
        _size = 2;
        c = (char*)malloc(_size);
        c[0] = (char)READ_CARD;
        c[1] = data[0]; // Address
        *size = _size;
    } else if (command == COMPATIBILITY_WRITE) {
        _size = 18;
        c = (char*)malloc(_size);
        c[0] = (char)COMPATIBILITY_WRITE;
        c[1] = data[0]; // start address
        for (char i=0; i<(_size-2); i++) c[2+i] = data[1+i]; //writed data
        *size = _size;
    } else if (command == WRITE_CARD) {
        _size = 6;
        c = (char*)malloc(_size);
        c[0] = (char)WRITE_CARD;
        c[1] = data[0]; // start address
        for (int i=0; i<(_size-2); i++) c[2+i] = data[1+i]; //writed data
        *size = _size;
    } else if (command == MIFR_CLASSIC_AUTHE) { // only for MIFARE Classic (1K Or 4K)
        _size = 9;
        c = (char*)malloc(_size);
        c[0] = (char)MIFR_CLASSIC_AUTHE;
        c[1] = data[0]; // section
        c[2] = data[1]; // keyNum
        for (int i=0; i<(_size-3); i++) c[3+i] = data[2+i]; //writed data
        *size = _size;
    } else if (command == MIFR_UC_AUTHE) { // only for MIFARE UltralightC
        _size = 17;
        c = (char*)malloc(_size);
        c[0] = (char)MIFR_UC_AUTHE;
        for (int i=0; i<(_size-1); i++) c[1+i] = data[i]; //writed data
        *size = _size;
    } else if (command == MIFR_NTAG21X_AUTHE) { // only for MIFARE NTAG213
        _size = 17;
        c = (char*)malloc(_size);
        c[0] = (char)MIFR_NTAG21X_AUTHE;
        for (int i=0; i<(_size-1); i++) c[1+i] = data[i]; //writed data
        *size = _size;
    } else if (command == BEEP) {
        c = (char*)malloc(2);
        c[0] = (char)BEEP;
        c[1] = data[0]; // Beep Time
        *size = 2;
    } else if (command == LED) {
        c = (char*)malloc(3);
        c[0] = (char)LED;
        c[1] = data[0]; // LED RED/GREEN
        c[2] = data[1]; // ON/OFF
        *size = 3;
    }
    *ret = c;
}

static char checksum(char* c, int len) {
    char total = c[2];
    for (int i=0; i<len ;i++)
        total += c[3+i];
    return total;
}

char* makeSendPackage(char* command, int len) {
    int i;
    char* c = (char*)malloc(len+6);
    c[0] = 0x55;
    c[1] = 0xAA;
    c[2] = len+1; // include checksum
    for (i=0; i<len; i++) c[3+i] = command[i];
    c[3+i] = checksum(c, len);
    c[3+i+1] = 0xAA;
    c[3+i+2] = 0x55;
    free(command);
    return c;
}

char* makeReadPackage(CARDCOMMAND command) {
}

int send(char* package, int size) {
    free(package);
}

int read(char* package, int size) {
    free(package);
}