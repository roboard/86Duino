#ifndef ECRFID_H
#define ECRFID_H

#include "Arduino.h"
#include "Ethercat.h"
#include "SerialEVA.h"
#include "RFIDtype.h"

enum ECRFIDDevice {
    RC522 = 0x1001,
    PN532 = 0x1002
};

class ECRFID
{
    private:
        EthercatDevice_DmpHID_Generic* slave;
        int COMX;
        HardwareSerial* _hs;
        struct _RFIDinfo myRFID;
        CARDCOMMAND command;
        unsigned long _t;
        char buf[64];
        
    public:
        ECRFID();
        void begin(void* slaveEva, ECRFIDDevice dev=RC522); // for ArduBlock
        void begin(void* slaveObj, int comport, uint32_t baud=115200, ECRFIDDevice dev=RC522); // for programmer
        void begin(int comport, int baud=115200, ECRFIDDevice dev=RC522); // for programmer, it is local COM port

        bool scan();
        void update();
        int getType();
        int getMemSize();
        int getUIDSize();
        unsigned char getUIDByte(int index);
        bool read(char address, char* result);
        bool selectCard(char uidSize, char* uid);
        bool write4B(char address, char* userData);
        bool CWrite(char address, char* userData, int userDataSize);
        bool MIFR_CA(char sector, char keyNum, char* userData);
        bool MIFR_UCA(char* userData);
        bool MIFR_21X_AUTHE(char* userData);
        bool Beep(char t);
        bool Led(char which, bool onoff);
        int available();
        void _printResult();
        int pushResultToBuf(char* result, unsigned int len);
};
extern ECRFID rfid;

#endif