#include "ECRFID.h"

EthercatMaster EcatMaster;
EthercatDevice_QECR00HU9S Slave;
MyEVASerial SerialEVA;
unsigned long t = 0;

void setup() {
  Serial.begin(115200);

  EcatMaster.begin(ECAT_ETH_0, NULL);
  Slave.attach(0, EcatMaster, ECAT_SLAVE_NO);
  EcatMaster.start();
  
  SerialEVA.init(&Slave, COM1);
  SerialEVA.begin(115200);
  
  rfid.begin(&SerialEVA, RC522);
  rfid.scan();
  t = millis();
}

void loop() {
  if ((millis() - t) > 1000) {
    rfid.scan();
    t = millis();
  }
  
  if (rfid.available()) {
    if (rfid.getType() > 0) {
      Serial.print("RFID type=");
      Serial.println(rfid.getType(), HEX);
      Serial.print("RFID uid=");
      Serial.print(rfid.getUIDByte(0), HEX); Serial.print(" ");
      Serial.print(rfid.getUIDByte(1), HEX); Serial.print(" ");
      Serial.print(rfid.getUIDByte(2), HEX); Serial.print(" ");
      Serial.print(rfid.getUIDByte(3), HEX); Serial.println(" ");
    } else {
      Serial.println("unknown/no RFID Card");
    }
  }
  rfid.update();
}