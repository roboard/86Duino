#ifndef ECRFIDTYPE_H
#define ECRFIDTYPE_H


enum CARDID {
    MIFARE_CLASSIC,
    NTAG213,
    MIFARE_Ultralight_C
};

enum CARDTYPE {
    PICC_TYPE_MIFARE_MINI = 3,
    PICC_TYPE_MIFARE_1K,
    PICC_TYPE_MIFARE_4K,
    PICC_TYPE_MIFARE_ULC,
    PICC_TYPE_MIFARE_UL,
    PICC_TYPE_NTAG203,
    PICC_TYPE_NTAG213,
    PICC_TYPE_NTAG215,
    PICC_TYPE_NTAG216,
    UNKNOWN_TYPE = 0xFF
};

enum CARDCOMMAND {
    NO_COMMAND,
    SCAN_CARD,
    SELECT_CARD,
    READ_CARD,
    COMPATIBILITY_WRITE,
    WRITE_CARD,
    MIFR_CLASSIC_AUTHE,
    MIFR_UC_AUTHE,
    MIFR_NTAG21X_AUTHE,
    BEEP = 0xF0,
    LED
};

struct _RFIDinfo {
    int type;
    int memsize;
    int uid_size;
    unsigned char uid[7];
    int bank;
    int section;
};

void makeSendCommand(CARDCOMMAND command, char* data, char** ret, int* size);
char* makeSendPackage(char* command, int size);
char* makeReadPackage(CARDCOMMAND command);
int send(char* package, int size);
int read(char* package, int size);


#endif