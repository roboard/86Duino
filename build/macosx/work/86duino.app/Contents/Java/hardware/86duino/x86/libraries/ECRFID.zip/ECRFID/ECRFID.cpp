#include "ECRFID.h"

ECRFID::ECRFID() {
    myRFID.type = 0;
    myRFID.memsize = 0;
    myRFID.uid_size = 0;
    for (int i=0; i<7; i++) myRFID.uid[i] = 0;
    command = NO_COMMAND;
    _t = 0;
}

void ECRFID::begin(void* slaveEva, ECRFIDDevice dev) {
    if (slaveEva == NULL) return;
    
    if (dev == RC522) {
        slave = (EthercatDevice_DmpHID_Generic*)((MyEVASerial*)slaveEva)->_slave;
        COMX  = ((MyEVASerial*)slaveEva)->dev;
    }
}

void ECRFID::begin(void* slaveObj, int comport, uint32_t baud, ECRFIDDevice dev) {
    if (slaveObj == NULL) return;
    
    if (dev == RC522) {
        slave = (EthercatDevice_DmpHID_Generic*)slaveObj;
        slave->uartSetBaud(comport, baud);
        slave->uartSetFormat(comport, SERIAL_8N1);
        // or use below:
        // MyEVASerial* sEVA = new MyEVASerial();
        // sEVA->init(slave, candev);
        // sEVA->begin(baud);
        COMX  = comport;
    }
}

void ECRFID::begin(int comport, int baud, ECRFIDDevice dev) {
    if (comport < COM1 || comport > COM9) return;
    
    HardwareSerial* hs = new HardwareSerial(comport, baud, SERIAL_8N1, 0L, 500L);
    hs->begin(baud);
    _hs = hs;
}

void ECRFID::update()
{
    slave->update();
}

bool ECRFID::scan() {
    char* package;
    int pg_size;
    char data[2] = {0x0A, 0x00}; // need 100ms to scan 
    
    makeSendCommand(SCAN_CARD, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = SCAN_CARD;
    _t = millis();
    
    // printf("type=%04X\n", myRFID.type);
    // printf("memsize=%04X\n", myRFID.memsize);
    // printf("uid_size=%02X\n", myRFID.uid_size);
    // printf("uid=%02X %02X %02X %02X\n", myRFID.uid[0], myRFID.uid[1], myRFID.uid[2], myRFID.uid[3]);
    
    return true;
}

bool ECRFID::read(char address, char* result) {
    char* package;
    int i, pg_size;
    char data[1];
    
    data[0] = address;
    makeSendCommand(READ_CARD, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size+6);
    command = READ_CARD;
    _t = millis();
    
    return true;
}

bool ECRFID::selectCard(char uidSize, char* uid) {
    char* package;
    int i, pg_size;
    char data[8];
    
    data[0] = uidSize;
    for (i=0; i<7; i++) data[1+i] = uid[i];
    makeSendCommand(SELECT_CARD, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = SELECT_CARD;
    _t = millis();
    
    return true;
}

int ECRFID::getType() {
    if (myRFID.type == 0) return -1;
    return myRFID.type;
}

int ECRFID::getMemSize() {
    if (myRFID.memsize == 0) return -1;
    return myRFID.memsize;
}

int ECRFID::getUIDSize() {
    if (myRFID.uid_size == 0) return -1;
    return myRFID.uid_size;
}

unsigned char ECRFID::getUIDByte(int index) {
    if (myRFID.uid_size == 0 || index > 3 || index < 0) return 0;
    return myRFID.uid[index];
}

bool ECRFID::write4B(char address, char* userData) {
    char* package;
    int i, pg_size;
    char data[5];
    
    data[0] = address;
    for (i=0; i<4; i++) data[1+i] = userData[i];
    makeSendCommand(WRITE_CARD, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = WRITE_CARD;
    _t = millis();
    
    return true;
}

bool ECRFID::CWrite(char address, char* userData, int userDataSize) {
    char* package;
    int i, pg_size;
    char data[17];
    
    if (userDataSize > 15) return false;
    
    data[0] = address;
    for (i=0; i<userDataSize; i++) data[1+i] = userData[i];
    makeSendCommand(COMPATIBILITY_WRITE, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = COMPATIBILITY_WRITE;
    _t = millis();
    
    return true;
}

bool ECRFID::MIFR_CA(char sector, char keyNum, char* userData) {
    char* package;
    int i, pg_size;
    char data[8];
    
    data[0] = sector;
    data[1] = keyNum;
    for (i=0; i<6; i++) data[2+i] = userData[i];
    makeSendCommand(MIFR_CLASSIC_AUTHE, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = MIFR_CLASSIC_AUTHE;
    _t = millis();
    
    return true;
}

bool ECRFID::MIFR_UCA(char* userData) {
    char* package;
    int i, pg_size;
    char data[16];
    
    for (i=0; i<16; i++) data[i] = userData[i];
    makeSendCommand(MIFR_UC_AUTHE, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = MIFR_UC_AUTHE;
    _t = millis();
    
    return true;
}

bool ECRFID::MIFR_21X_AUTHE(char* userData) {
    char* package;
    int i, pg_size;
    char data[16];
    
    for (i=0; i<16; i++) data[i] = userData[i];
    makeSendCommand(MIFR_NTAG21X_AUTHE, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = MIFR_NTAG21X_AUTHE;
    _t = millis();
    
    return true;
}

bool ECRFID::Beep(char beepT) {
    char* package;
    int pg_size;
    char data[1];
    
    data[0] = beepT;
    makeSendCommand(BEEP, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = BEEP;
    _t = millis();
    
    return true;
}

bool ECRFID::Led(char which, bool onoff) {
    char* package;
    int pg_size;
    char data[2];
    
    data[0] = which; // RED or GREEN
    data[1] = onoff ? 1 : 0;
    makeSendCommand(LED, data, &package, &pg_size);
    package = makeSendPackage(package, pg_size);
    slave->uartSend(COMX, package, pg_size + 6);
    command = LED;
    _t = millis();
    
    return true;
}

void ECRFID::_printResult() {
    int c;
    c = slave->uartQueryRxQueue(COMX);
    if (c > 0) {
      for (;c > 0; c--) fprintf(stderr, "%x ", slave->uartRead(COMX));
      printf("\n");
    }
}

int ECRFID::available() {
    int i, c;
    
    if (command == NO_COMMAND || _t == 0) return 0;
    if ((millis() - _t) < 300) return 0;
    
    i = 0;
    c = slave->uartQueryRxQueue(COMX);
    if (c > 0) {
        for (;c > 0; c--) buf[i++] = (char)slave->uartRead(COMX);
        Serial.println("");
    }
    printf("1: %02X %02X %02X %02X\n", buf[0], buf[1], buf[3], buf[4]);
    if (buf[0] == 0 || buf[1] == 0) goto END;
    printf("2: %02X %02X %02X %02X\n", buf[0], buf[1], buf[3], buf[4]);
    if (buf[0] == 0x55 && buf[1] == 0xAA && buf[3] == (char)command && buf[4] == 0) goto END;
    printf("3\n");
    if (command == SCAN_CARD) {
        myRFID.type = buf[4];
        myRFID.memsize = ((unsigned short)buf[6] << 8) | buf[5];
        myRFID.uid_size = buf[7];
        for (i=0; i<myRFID.uid_size; i++) myRFID.uid[i] = buf[8+i];
    }
END:
    command = NO_COMMAND;
    _t = 0;
    
    return 1;
}

// Note: you need to give a little time before pushResultToBuf(), ex: 100ms
int ECRFID::pushResultToBuf(char* result, unsigned int len) {
    int i;
    
    // READ command, len is 16
    for (i=0; i<len; i++) result[i] = buf[5+i];

    return len;
}

ECRFID rfid;
