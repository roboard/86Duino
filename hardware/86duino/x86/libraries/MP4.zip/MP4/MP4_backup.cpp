/*
 * Copyright (c) 2000-2003 Fabrice Bellard
 *
 * This file is part of FFmpeg.
 *
 * FFmpeg is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * FFmpeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with FFmpeg; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/**
 * @file
 * multimedia converter based on the FFmpeg libraries
 */
#include "Arduino.h"
#include "Audio.h"
#include "Mp4.h"
#include "lame/lame.h"
#include "a9160.h"

#define SHOW_FRAMERATE
/*
const char program_name[] = "ffplay";
const int program_birth_year = 2003;

int selector = -1;

static void screenWrite(int sr, unsigned long offset, void *img, size_t img_size)
{
    unsigned long addr = offset;
    int nb, nd, n;
    char *buf = (char *)img;
    size_t len = img_size;
    
    if (sr == -1) return;
    
    if (len > 64) {
        n = addr & 0x03;
        if (n > 0) {
            n = 4 - n;
            _farsetsel(sr);
            switch (n) {
            case 3: _farnspokeb(addr++, *buf++);
            case 2: _farnspokeb(addr++, *buf++);
            case 1: _farnspokeb(addr++, *buf++);
            }
            len -= n;
        }
    }

    nd = len >> 2;
    nb = len & 0x03;
    
    if (nd > 0) {
        n = (nd + 15) >> 4;
        addr = addr - (((0 - nd) & 15) << 2);
        buf = buf - (((0 - nd) & 15) << 2);
        _farsetsel(sr);
        switch (nd & 15) {
        case 0: do { _farnspokel(addr + 0x00, ((unsigned long*)buf)[0x00]);
        case 15:     _farnspokel(addr + 0x04, ((unsigned long*)buf)[0x01]);
        case 14:     _farnspokel(addr + 0x08, ((unsigned long*)buf)[0x02]);
        case 13:     _farnspokel(addr + 0x0C, ((unsigned long*)buf)[0x03]);
        case 12:     _farnspokel(addr + 0x10, ((unsigned long*)buf)[0x04]);
        case 11:     _farnspokel(addr + 0x14, ((unsigned long*)buf)[0x05]);
        case 10:     _farnspokel(addr + 0x18, ((unsigned long*)buf)[0x06]);
        case 9:      _farnspokel(addr + 0x1C, ((unsigned long*)buf)[0x07]);
        case 8:      _farnspokel(addr + 0x20, ((unsigned long*)buf)[0x08]);
        case 7:      _farnspokel(addr + 0x24, ((unsigned long*)buf)[0x09]);
        case 6:      _farnspokel(addr + 0x28, ((unsigned long*)buf)[0x0A]);
        case 5:      _farnspokel(addr + 0x2C, ((unsigned long*)buf)[0x0B]);
        case 4:      _farnspokel(addr + 0x30, ((unsigned long*)buf)[0x0C]);
        case 3:      _farnspokel(addr + 0x34, ((unsigned long*)buf)[0x0D]);
        case 2:      _farnspokel(addr + 0x38, ((unsigned long*)buf)[0x0E]);
        case 1:      _farnspokel(addr + 0x3C, ((unsigned long*)buf)[0x0F]);
                     addr += 0x40;
                     buf += 0x40;
                } while (--n > 0);
        }
    }
    
    switch (nb) {
    case 3: _farsetsel(sr);
            _farnspokew(addr, ((unsigned short*)buf)[0]);
            _farnspokeb(addr + 2, buf[2]);
            return;
    case 2: _farpokew(sr, addr, ((unsigned short*)buf)[0]);
            return;
    case 1: _farpokeb(sr, addr, buf[0]);
    }
}

static uint8_t pic[1600];
static void SaveFrame(AVFrame *pFrame, int width, int height, int iFrame)
{
    // 240p -> 480p
    int x, y, _x, ax, _y, _h1;
    int widthpixel = 400 * 2;
    
    for (y = 0; y < 240; y++) {
        _h1 = y * 3200;
        for (x=0, _x=0; x < pFrame->linesize[0]; x+=2, _x+=4) {
            pic[_x]   = *(pFrame->data[0] + x + y * widthpixel);
            pic[_x+1] = *(pFrame->data[0] + x + y * widthpixel + 1);
            pic[_x+2] = *(pFrame->data[0] + x + y * widthpixel);
            pic[_x+3] = *(pFrame->data[0] + x + y * widthpixel + 1);
        }
        screenWrite(selector, _h1, pic, 1600);
        _y = _h1 + 1600;
        screenWrite(selector, _y, pic, 1600);
    }
    
    // 480p
    screenWrite(selector, 0, pFrame->data[0], pFrame->linesize[0]*height);
    
    // printf("Frame %d linesize %d\n", iFrame, pFrame->linesize[0]);
    // fclose(pFile);
}

void vgaInit(void) {
    a9160_Init(800, 480);
    selector = get_a9160_fb_selector();
    Audio.begin(88200, 100);
}

void lcdInit(void) {
    lcd_on(1);
    selector = get_lcd_fb_selector();
    Audio.begin(88200, 100);
}

void lcdClose(void) {
    lcd_off();
}


void playMP4(const char* filename, unsigned int volume) {
    AVFormatContext *pFormatCtx = NULL;
    int             i, videoStream, audioStream;
    AVCodecContext  *pCodecCtx;
    AVCodecContext  *c; // Audio
    AVFrame         *frame; // Audio
    SwrContext      *swrCtx; // Audio
    AVCodec         *codec; // Audio
    AVCodec         *pCodec;
    AVFrame         *pFrame;
    AVFrame         *pFrameRGB;
    AVPacket        packet;
    int             ret, frameFinished;
    int             numBytes;
    uint8_t         *buffer;
    #ifdef SHOW_FRAMERATE
    uint32_t        _tt, _tt_t, _frameNum = 0L;
    #endif
    
    if (volume > 1023) volume = 1024;
    Audio.prepare(NULL, 0, volume);
    
    av_register_all();
    
    pFormatCtx = avformat_alloc_context();
    
    if( avformat_open_input(&pFormatCtx, filename, NULL, NULL) != 0 )
        return;

    if( avformat_find_stream_info(pFormatCtx, NULL ) < 0 )
        return;
 
    av_dump_format(pFormatCtx, -1, filename, 0);
    
    videoStream = -1;
    for( i = 0; i < pFormatCtx->nb_streams; i++ )
        if( pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            videoStream = i;
            break;
    }
    
    audioStream = -1;
    for( i = 0; i < pFormatCtx->nb_streams; i++ )
        if( pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_AUDIO) {
            audioStream = i;
            break;
    }
 
    if( videoStream == -1 || audioStream == -1)
        return;

    pCodecCtx = pFormatCtx->streams[videoStream]->codec;
    c = pFormatCtx->streams[audioStream]->codec;
    
    pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
    codec = avcodec_find_decoder(c->codec_id);
    if( pCodec == NULL || codec == NULL)
        return;

    if( avcodec_open2(pCodecCtx, pCodec, NULL) < 0 )
        return;
    
    if( avcodec_open2(c, codec, NULL) < 0 )
        return;

    pFrame = av_frame_alloc();
    if( pFrame == NULL )
        return;

    pFrameRGB = av_frame_alloc();
    if( pFrameRGB == NULL )
        return;
    
    numBytes = avpicture_get_size(AV_PIX_FMT_RGB565LE, pCodecCtx->width, pCodecCtx->height);
    
    buffer = (uint8_t*)av_malloc(numBytes);
 
    avpicture_fill( (AVPicture *)pFrameRGB, (const uint8_t *)buffer, AV_PIX_FMT_RGB565LE, pCodecCtx->width, pCodecCtx->height);
    
    i = 0;
    // Audio
    frame = av_frame_alloc();
	swrCtx = swr_alloc();
    
	enum AVSampleFormat in_sample_fmt = c->sample_fmt;
	enum AVSampleFormat out_sample_fmt = AV_SAMPLE_FMT_S16;
	int in_sample_rate = c->sample_rate;
	int out_sample_rate = c->sample_rate;
	uint64_t in_ch_layout = c->channel_layout;
	uint64_t out_ch_layout = AV_CH_LAYOUT_STEREO;
    
    av_opt_set_int(swrCtx, "in_channel_layout", in_ch_layout, 0);  
	av_opt_set_int(swrCtx, "in_sample_rate", in_sample_rate, 0);  
	av_opt_set_sample_fmt(swrCtx, "in_sample_fmt",in_sample_fmt, 0);  
	av_opt_set_int(swrCtx, "out_channel_layout",out_ch_layout, 0);  
	av_opt_set_int(swrCtx, "out_sample_rate", out_sample_rate, 0);  
	av_opt_set_sample_fmt(swrCtx, "out_sample_fmt",out_sample_fmt, 0); 
    
    swr_init(swrCtx);
    
    int out_channel_nb = av_get_channel_layout_nb_channels(out_ch_layout);
	//儲存pcm資料
	int out_size = (out_channel_nb*out_sample_rate*16)/8.0;		//1秒的資料大小
	uint8_t *out_buffer = (uint8_t *) av_malloc(out_size/2);
	// FILE *fp_pcm = fopen(outfilename, "wb");
	int got_frame, framecount = 0;
    #ifdef SHOW_FRAMERATE
    _tt = millis();
    #endif
    while( true ) {
        if (av_read_frame(pFormatCtx, &packet) < 0) break;
        if (packet.stream_index == audioStream) {
			while(packet.size > 0)
			{
				ret = avcodec_decode_audio4(c, frame, &got_frame, &packet);
				if (ret < 0) 
				{
					printf("%s", "decode error\n");
					break;
				}
                
				if (got_frame) 
				{
					int dst_nb_samples = av_rescale_rnd(swr_get_delay(swrCtx, c->sample_rate) + frame->nb_samples,
						out_sample_rate, c->sample_rate, AV_ROUND_UP);
                    
					swr_convert(swrCtx, &out_buffer, dst_nb_samples,(const uint8_t **)frame->data, frame->nb_samples);
					
					int out_buffer_size = av_samples_get_buffer_size(NULL, out_channel_nb, frame->nb_samples, out_sample_fmt, 1);

					Audio.write(out_buffer, out_buffer_size);
				}
                
				packet.data += ret;
				packet.size -= ret;  
			}
		}
        if ( packet.stream_index == videoStream ) {
            avcodec_decode_video2(pCodecCtx, pFrame, &frameFinished, &packet);
            
            if( frameFinished ) {
                struct SwsContext *img_convert_ctx = NULL;
                img_convert_ctx = sws_getCachedContext(img_convert_ctx, pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_RGB565LE, SWS_FAST_BILINEAR, NULL, NULL, NULL);
                if( !img_convert_ctx ) {
                  fprintf(stderr, "Cannot initialize sws conversion context\n");
                  exit(1);
                }
                sws_scale(img_convert_ctx, (const uint8_t* const*)pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameRGB->data, pFrameRGB->linesize);
                // printf("i=%d\n", i++);
                SaveFrame(pFrameRGB, pCodecCtx->width, pCodecCtx->height, i++);
            }
        }
        av_free_packet(&packet);
        #ifdef SHOW_FRAMERATE
        _tt_t = millis() - _tt;
        if (_tt_t > 1000) {
            printf("frame: %d\n", _frameNum+1);
            _tt = millis();
            _frameNum = 0;
        } else
            _frameNum++;
        #endif
    }
    
    av_frame_free(&frame);
	av_free(out_buffer);
	swr_free(&swrCtx);
	avcodec_close(c);
    
    av_free(buffer);
    av_free(pFrameRGB);
    av_free(pFrame);
    avcodec_close(pCodecCtx);
    avformat_close_input(&pFormatCtx);
}

#define AUDIO_INBUF_SIZE 20480
#define AUDIO_REFILL_THRESH 4096

static void decode(AVCodecContext *dec_ctx, AVPacket *pkt, AVFrame *frame,
                   FILE *outfile)
{
    int i, ch;
    int ret, data_size;

    ret = avcodec_send_packet(dec_ctx, pkt);
    if (ret < 0) {
        fprintf(stderr, "Error submitting the packet to the decoder\n");
        exit(1);
    }

    while (ret >= 0) {
        ret = avcodec_receive_frame(dec_ctx, frame);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
            return;
        else if (ret < 0) {
            fprintf(stderr, "Error during decoding\n");
            exit(1);
        }
        data_size = av_get_bytes_per_sample(dec_ctx->sample_fmt);
        if (data_size < 0) {
            // This should not occur, checking just for paranoia
            fprintf(stderr, "Failed to calculate data size\n");
            exit(1);
        }

		printf("+++++ FLC-DBG: data_size = %d +++++\n", data_size); //单通道样本（sample）大小
		printf("+++++ FLC-DBG: frame->nb_samples = %d +++++\n", frame->nb_samples); //帧个数
		printf("+++++ FLC-DBG: dec_ctx->channels = %d +++++\n", dec_ctx->channels); //通道数
		printf("+++++ FLC-DBG: frame->linesize[0] = %d +++++\n", frame->linesize[0]); //frame->data[0]数据长度（Bytes）
		printf("+++++ FLC-DBG: frame->linesize[1] = %d +++++\n", frame->linesize[1]);
		//FLAC格式的文件，解码后数据都放在frame->data[0]中，长度可根据frame->linesize[0]来获取。
		//原始代码不同声道数据存在不同的frame->data[i]中。
        // for (i = 0; i < frame->nb_samples; i++)
            // for (ch = 0; ch < dec_ctx->channels; ch++)
               // fwrite(frame->data[ch] + data_size*i, 1, data_size, outfile);

		//仅保存单通道数据。
		//for (i = 0; i < frame->nb_samples; i++)
		//	fwrite(frame->data[0] + i * data_size*dec_ctx->channels, 1, data_size, outfile);
		
		//保存全部通道
		fwrite(frame->data[0], 1, frame->linesize[0], outfile);
    }
}

int playAudio(const char* filename, unsigned int volume) {
    const char *outfilename = "myAudio.pcm";
    AVFormatContext *pFormatCtx = NULL;
    int             i, audioStream;
    AVCodec         *pCodec;
    const AVCodec *codec;
    AVCodecContext *c= NULL;
    AVCodecParserContext *parser = NULL;
    int len, ret;
    FILE *f, *outfile;
    uint8_t inbuf[AUDIO_INBUF_SIZE + AV_INPUT_BUFFER_PADDING_SIZE];
    uint8_t *data;
    size_t   data_size;
    AVPacket *pkt;
    AVFrame *decoded_frame = NULL;
    
    if (volume > 1023) volume = 1024;
    Audio.prepare(NULL, 0, volume);
    
    av_register_all();

    pFormatCtx = avformat_alloc_context();
    
    if( avformat_open_input(&pFormatCtx, filename, NULL, NULL) != 0 )
        return 1;

    if( avformat_find_stream_info(pFormatCtx, NULL ) < 0 )
        return 1;
 
    // av_dump_format(pFormatCtx, -1, filename, 0);
    
    audioStream = -1;
    for( i = 0; i < pFormatCtx->nb_streams; i++ )
        if( pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_AUDIO) {
            audioStream = i;
            break;
    }
 
    if( audioStream == -1 ) {
        printf("No find Audio channel\n");
        return 1;
    }

	// pkt = av_packet_alloc();

    // find the MPEG audio decoder
	//此处修改为FLAC的codec id。
    //codec = avcodec_find_decoder(AV_CODEC_ID_MP2);
    c = pFormatCtx->streams[audioStream]->codec;
    codec = avcodec_find_decoder(c->codec_id);
    //codec = avcodec_find_decoder(AV_CODEC_ID_FLAC);
    if( codec == NULL ) {
        printf("No find decoder\n");
        return 1;
    }
    
    if (!codec) {
        fprintf(stderr, "Codec not found\n");
        exit(1);
    }

    // parser = av_parser_init(codec->id);
    // if (!parser) {
        // fprintf(stderr, "Parser not found\n");
        // exit(1);
    // }

    // c = avcodec_alloc_context3(codec);
    // if (!c) {
        // fprintf(stderr, "Could not allocate audio codec context\n");
        // exit(1);
    // }

    // open it
    if (avcodec_open2(c, codec, NULL) < 0) {
        fprintf(stderr, "Could not open codec\n");
        exit(1);
    }


    // f = fopen(filename, "rb");
    // if (!f) {
        // fprintf(stderr, "Could not open %s\n", filename);
        // exit(1);
    // }
    // outfile = fopen(outfilename, "wb");
    // if (!outfile) {
        // av_free(c);
        // exit(1);
    // }

    //編碼資料
	AVPacket *packet = (AVPacket *)av_malloc(sizeof(AVPacket));
	//解壓縮資料
	AVFrame *frame = av_frame_alloc();

	//frame->16bit 44100 PCM 統一音訊取樣格式與取樣率
	SwrContext *swrCtx = swr_alloc();
	//重取樣設定選項
	//輸入的取樣格式
	enum AVSampleFormat in_sample_fmt = c->sample_fmt;
	//輸出的取樣格式 16bit PCM
	enum AVSampleFormat out_sample_fmt = AV_SAMPLE_FMT_S16;
	//輸入的取樣率
	int in_sample_rate = c->sample_rate;
	//輸出的取樣率
	int out_sample_rate = c->sample_rate;//如果指定輸出的取樣率與 c->sample_rate相差很大時，swr_convert輸出的pcm有噪音，需要使用AVAudioFifo做分包處理。
	//輸入的聲道佈局
	uint64_t in_ch_layout = c->channel_layout;
	//輸出的聲道佈局
	uint64_t out_ch_layout = AV_CH_LAYOUT_STEREO;//AV_CH_LAYOUT_MONO，單通道；AV_CH_LAYOUT_STEREO,雙聲道

    av_opt_set_int(swrCtx, "in_channel_layout", in_ch_layout, 0);  
	av_opt_set_int(swrCtx, "in_sample_rate", in_sample_rate, 0);  
	av_opt_set_sample_fmt(swrCtx, "in_sample_fmt",in_sample_fmt, 0);  
	av_opt_set_int(swrCtx, "out_channel_layout",out_ch_layout, 0);  
	av_opt_set_int(swrCtx, "out_sample_rate", out_sample_rate, 0);  
	av_opt_set_sample_fmt(swrCtx, "out_sample_fmt",out_sample_fmt, 0); 
    
    swr_init(swrCtx);
    
    //獲取輸出的聲道個數
	int out_channel_nb = av_get_channel_layout_nb_channels(out_ch_layout);
	//儲存pcm資料
	int out_size = (out_channel_nb*out_sample_rate*16)/8.0;		//1秒的資料大小
	uint8_t *out_buffer = (uint8_t *) av_malloc(out_size/2);
	// FILE *fp_pcm = fopen(outfilename, "wb");
	int got_frame, framecount = 0;
	//6.一幀一幀讀取壓縮的音訊資料AVPacket
	while (av_read_frame(pFormatCtx, packet) >= 0) 
	{
		if (packet->stream_index == audioStream) 
		{
			while(packet->size > 0)
			{
				ret = avcodec_decode_audio4(c, frame, &got_frame, packet);
				if (ret < 0) 
				{
					printf("%s", "decode error\n");
					break;
				}
				//解碼成功
				if (got_frame) 
				{
					printf("Decode %d frame\n", framecount++);
					int dst_nb_samples = av_rescale_rnd(swr_get_delay(swrCtx, c->sample_rate) + frame->nb_samples,
						out_sample_rate, c->sample_rate, AV_ROUND_UP);
					//av_samples_alloc(&out_buffer, NULL, out_channel_nb, dst_nb_samples, out_sample_fmt, 0);
					swr_convert(swrCtx, &out_buffer, dst_nb_samples,(const uint8_t **)frame->data, frame->nb_samples);
					//swr_convert(swrCtx, &out_buffer, out_channel_nb * out_sample_rate,(const uint8_t **)frame->data, frame->nb_samples);
					//獲取sample的size
					int out_buffer_size = av_samples_get_buffer_size(NULL, out_channel_nb, frame->nb_samples,
						out_sample_fmt, 1);
					//寫入檔案
					// fwrite(out_buffer, 1, out_buffer_size, fp_pcm);
					Audio.write(out_buffer, out_buffer_size);
				}
				// 更新解碼包的資訊
				packet->data += ret;
				packet->size -= ret;  
			}
		}
		av_free_packet(packet);
	}
    
    
    // fclose(fp_pcm);
    printf("%s have been created.\n", outfilename);
    av_frame_free(&frame);
	av_free(out_buffer);
	swr_free(&swrCtx);
	avcodec_close(c);
	avformat_close_input(&pFormatCtx);
    
    return 0;
}
*/

// From: https://github.com/leixiaohua1020/simplest_ffmpeg_audio_player/blob/master/simplest_ffmpeg_audio_decoder/simplest_ffmpeg_audio_decoder.cpp
#define MAX_AUDIO_FRAME_SIZE (192000)
int MP3ToPCM(const char *outfilename, const char *filename)
{
    AVFormatContext	*pFormatCtx;
	int				i, audioStream;
	AVCodecContext	*pCodecCtx;
	AVCodec			*pCodec;
	AVPacket		    *packet;
	uint8_t			**out_buffer;
    int             dst_linesize;
	AVFrame			*pFrame;
    int ret;
	uint32_t len = 0;
	int got_picture;
	int index = 0;
	int64_t in_channel_layout;
	struct SwrContext *au_convert_ctx;

    if (outfilename == NULL || filename == NULL) return -1;
    
    Audio.begin(22050, 8);
    Audio.prepare(NULL, 0, 8);
    
	FILE *pFile=fopen(outfilename, "wb");
	const char* url = filename;

	av_register_all();
	avformat_network_init();
	pFormatCtx = avformat_alloc_context();
	//Open
	if(avformat_open_input(&pFormatCtx,url,NULL,NULL)!=0){
		printf("Couldn't open input stream.\n");
		return -1;
	}
	// Retrieve stream information
	if(avformat_find_stream_info(pFormatCtx,NULL)<0){
		printf("Couldn't find stream information.\n");
		return -1;
	}
	// Dump valid information onto standard error
	av_dump_format(pFormatCtx, 0, url, false);

	// Find the first audio stream
	audioStream=-1;
	for (i=0; i < pFormatCtx->nb_streams; i++)
		if(pFormatCtx->streams[i]->codec->codec_type==AVMEDIA_TYPE_AUDIO){
			audioStream=i;
			break;
		}

	if (audioStream==-1){
		printf("Didn't find a audio stream.\n");
		return -1;
	}

	// Get a pointer to the codec context for the audio stream
	pCodecCtx=pFormatCtx->streams[audioStream]->codec;

	// Find the decoder for the audio stream
	pCodec=avcodec_find_decoder(pCodecCtx->codec_id);
	if (pCodec==NULL) {
		printf("Codec not found.\n");
		return -1;
	}

	// Open codec
	if (avcodec_open2(pCodecCtx, pCodec,NULL)<0) {
		printf("Could not open codec.\n");
		return -1;
	}

	packet=(AVPacket *)av_malloc(sizeof(AVPacket));
	av_init_packet(packet);

	//Out Audio Param
	uint64_t out_channel_layout=AV_CH_LAYOUT_MONO;//AV_CH_LAYOUT_STEREO;
	//nb_samples: AAC-1024 MP3-1152
	int out_nb_samples=pCodecCtx->frame_size;
	AVSampleFormat out_sample_fmt=AV_SAMPLE_FMT_S16;
	int out_sample_rate=44100;
	int out_channels=av_get_channel_layout_nb_channels(out_channel_layout);
	//Out Buffer Size
	//int out_buffer_size=av_samples_get_buffer_size(NULL, out_channels , out_nb_samples, out_sample_fmt, 1);

    ret = av_samples_alloc_array_and_samples(&dst_data, &dst_linesize, dst_nb_channels,
                                             dst_nb_samples, dst_sample_fmt, 0);
    if (ret < 0) {
        fprintf(stderr, "Could not allocate destination samples\n");
        goto end;
    }
    
	out_buffer=(uint8_t *)av_malloc(MAX_AUDIO_FRAME_SIZE*2);
	pFrame=av_frame_alloc();

	//FIX:Some Codec's Context Information is missing
	in_channel_layout=av_get_default_channel_layout(pCodecCtx->channels);
	//Swr
	au_convert_ctx = swr_alloc();
	au_convert_ctx=swr_alloc_set_opts(au_convert_ctx, out_channel_layout, out_sample_fmt, out_sample_rate,
		in_channel_layout, pCodecCtx->sample_fmt , pCodecCtx->sample_rate, 0, NULL);
	swr_init(au_convert_ctx);

	while(av_read_frame(pFormatCtx, packet)>=0){
		if(packet->stream_index==audioStream){

			ret = avcodec_decode_audio4(pCodecCtx, pFrame, &got_picture, packet);
			if ( ret < 0 ) {
                printf("Error in decoding audio frame.\n");
                return -1;
            }
			if ( got_picture > 0 ) {
                int out_samples = av_rescale_rnd(swr_get_delay(au_convert_ctx, pCodecCtx->sample_rate) + pFrame->nb_samples, 44100, pCodecCtx->sample_rate, AV_ROUND_UP);
                // av_samples_alloc(&out_buffer, NULL, out_channels, out_samples, AV_SAMPLE_FMT_S16, 1);
				swr_convert(au_convert_ctx, &out_buffer, MAX_AUDIO_FRAME_SIZE,(const uint8_t **)pFrame->data , pFrame->nb_samples);
                int out_buffer_size = av_samples_get_buffer_size(NULL, out_channels, pFrame->nb_samples, out_sample_fmt, 1);
				//printf("index:%5d\t pts:%lld\t packet size:%d\n",index,packet->pts,packet->size);
				//Write PCM
				//fwrite(out_buffer, 1, out_buffer_size, pFile);
                //short* buf = (short*)malloc(out_buffer_size * sizeof(short));
                //for (int i=0, j=0; i<out_buffer_size; i++, j++) {
                //  buf[j] = out_buffer[i];
                //  //buf[j+1] = out_buffer[i];
                //}
                Audio.write(out_buffer, out_buffer_size);
                //free(buf);
				index++;
			}
		}
		av_free_packet(packet);
	}

	swr_free(&au_convert_ctx);

	fclose(pFile);

	av_free(out_buffer);
	// Close the codec
	avcodec_close(pCodecCtx);
	// Close the video file
	avformat_close_input(&pFormatCtx);
    // Audio close
    Audio.end();

	return 0;
}

/*
SwrContext * ffmpeg_init_pcm_resample(Out_stream_info * out_stream_info,AVFrame *in_frame, AVFrame *out_frame)
{
	SwrContext * swr_ctx = NULL;  
	swr_ctx = swr_alloc();  
	if (!swr_ctx)  
	{  
		printf("swr_alloc error \n");  
		return NULL;  
	}  
	AVCodecContext * audio_dec_ctx = m_icodec->streams[m_in_audio_stream_idx]->codec;  
	AVSampleFormat sample_fmt;  
	sample_fmt = (AVSampleFormat)out_stream_info->m_dwBitsPerSample; //样本  
	int out_channel_layout = av_get_default_channel_layout(out_stream_info->m_dwChannelCount);
	if (audio_dec_ctx->channel_layout == 0)  
	{  
		audio_dec_ctx->channel_layout = av_get_default_channel_layout(m_icodec->streams[m_in_audio_stream_idx]->codec->channels);  
	}  
	// set options 
	av_opt_set_int(swr_ctx, "in_channel_layout",    audio_dec_ctx->channel_layout, 0);  
	av_opt_set_int(swr_ctx, "in_sample_rate",       audio_dec_ctx->sample_rate, 0);  
	av_opt_set_sample_fmt(swr_ctx, "in_sample_fmt", audio_dec_ctx->sample_fmt, 0);  
	av_opt_set_int(swr_ctx, "out_channel_layout",   out_channel_layout, 0);   
	av_opt_set_int(swr_ctx, "out_sample_rate",       out_stream_info->m_dwFrequency, 0);  
	av_opt_set_sample_fmt(swr_ctx, "out_sample_fmt", sample_fmt, 0);  
	swr_init(swr_ctx);  
 
	int64_t src_nb_samples = in_frame->nb_samples; 
	//计算输出的samples 和采样率有关 例如：48000转44100，samples则是从1152转为1059，除法
	out_frame->nb_samples = av_rescale_rnd(src_nb_samples, out_stream_info->m_dwFrequency, audio_dec_ctx->sample_rate, AV_ROUND_UP);
 
	int ret = av_samples_alloc(out_frame->data, &out_frame->linesize[0],   
		out_stream_info->m_dwChannelCount, out_frame->nb_samples,out_stream_info->m_oaudio_st->codec->sample_fmt,1);  
	if (ret < 0)  
	{  
		return NULL;  
	}  
 
	out_stream_info->m_audiofifo  = av_audio_fifo_alloc(out_stream_info->m_oaudio_st->codec->sample_fmt, out_stream_info->m_oaudio_st->codec->channels,  
		out_frame->nb_samples);   
 
	return swr_ctx;  
}
 
int ffmpeg_preform_pcm_resample(Out_stream_info * out_stream_info,SwrContext * pSwrCtx,AVFrame *in_frame, AVFrame *out_frame)
{
	int ret = 0;
	int samples_out_per_size = 0;              //转换之后的samples大小
  
	if (pSwrCtx != NULL)   
	{  
		//这里注意下samples_out_per_size这个值和 out_frame->nb_samples这个值有时候不一样，ffmpeg里面做了策略不是问题。
		samples_out_per_size = swr_convert(pSwrCtx, out_frame->data, out_frame->nb_samples,   
			(const uint8_t**)in_frame->data, in_frame->nb_samples);  
		if (samples_out_per_size < 0)  
		{  
			return -1;  
		}  
 
		AVCodecContext * audio_dec_ctx = m_icodec->streams[m_in_audio_stream_idx]->codec; 
 
		int buffersize_in = av_samples_get_buffer_size(&in_frame->linesize[0],audio_dec_ctx->channels,  
			in_frame->nb_samples, audio_dec_ctx->sample_fmt, 1);
 
		//修改分包内存  
		int buffersize_out = av_samples_get_buffer_size(&out_frame->linesize[0], out_stream_info->m_oaudio_st->codec->channels,  
			samples_out_per_size, out_stream_info->m_oaudio_st->codec->sample_fmt, 1); 
 
		int fifo_size = av_audio_fifo_size(out_stream_info->m_audiofifo);  
		fifo_size = av_audio_fifo_realloc(out_stream_info->m_audiofifo, av_audio_fifo_size(out_stream_info->m_audiofifo) + out_frame->nb_samples);  
		av_audio_fifo_write(out_stream_info->m_audiofifo,(void **)out_frame->data,samples_out_per_size);  
		fifo_size = av_audio_fifo_size(out_stream_info->m_audiofifo); 
 
		out_frame->pkt_pts = in_frame->pkt_pts;  
		out_frame->pkt_dts = in_frame->pkt_dts;  
		//有时pkt_pts和pkt_dts不同，并且pkt_pts是编码前的dts,这里要给avframe传入pkt_dts而不能用pkt_pts  
		//out_frame->pts = out_frame->pkt_pts;  
		out_frame->pts = in_frame->pkt_dts;  
 
		//测试用
		if (out_stream_info->user_stream_id ==11)
		{
			if (pcm_file == NULL)
			{
				pcm_file = fopen("11.pcm","wb");
			}
			int wtiresize = fwrite(out_frame->data[0],buffersize_out,1, pcm_file);
			fflush(pcm_file);
		}
	}  
	ret = 1;
	return ret;
}
 
void ffmpeg_uinit_pcm_resample(SwrContext * swr_ctx,AVAudioFifo * audiofifo)
{ 
	if (swr_ctx)  
	{  
		swr_free(&swr_ctx);  
		swr_ctx = NULL;  
	}  
	if(audiofifo)  
	{  
		av_audio_fifo_free(audiofifo);  
		audiofifo = NULL;  
	}     
}
*/

