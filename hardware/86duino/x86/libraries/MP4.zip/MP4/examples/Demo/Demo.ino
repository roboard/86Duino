#include "MP4.h"
#include "lcd.h"

void setup(void) {
    lcdInit();
    //playMP4("demo.mp4", 4);
    playAudio("demo.mp4", 4);
    lcdClose();
}

void loop(void) {
}